from typing import List, Optional

__version__ = "23.2.0"


def main(args: Optional[List[str]] = None) -> int:
    """This is an internal API only meant for use by chainner_pip's own console scripts.

    For additional details, see https://github.com/pypa/chainner_pip/issues/7498.
    """
    from chainner_pip._internal.utils.entrypoints import _wrapper

    return _wrapper(args)
